# A simple package

## Provide some utility functions

**Example:**

*Count matching string in a list*

```
    count_in_list(["toto", "tata", "toto"], "toto") 
    output: 2
```