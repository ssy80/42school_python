from setuptools import setup, find_packages

setup(
    name='ft_package',
    version='0.0.1',
    author='ssian',
    author_email='ssian@42mail.sutd.edu.sg',
    description='A simple package',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/ssian/ft_package',
    packages=find_packages(),
    python_requires='>=3.6',
    license='MIT',
)

"""
setup(
    name='ft_package',
    version='0.0.1',
    author='eagle',
    author_email='eagle@42.fr',
    description='A sample test package',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',

    url='https://github.com/eagle/ft_package',  # Shows as Home-page

    packages=find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
    license='MIT',
)
"""

"""
$>pip show -v ft_package
Name: ft_package
Version: 0.0.1
Summary: A sample test package

Home-page: https://github.com/eagle/ft_package
Author: eagle
Author-email: eagle@42.fr

License: MIT

Location: /home/eagle/...
Requires:
Required-by:
Metadata-Version: 2.1
Installer: pip
Classifiers:
Entry-points:
$>
"""